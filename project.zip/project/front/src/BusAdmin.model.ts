export class BusAdmin{
    public busno : string ='';
    public agency : string = '';
    public busType : string = '';
    public departureCity : string = '';
    public arrivalCity : string = '';
    
    
    public dateOfDeparture : string = '';
    public price : number = 0;
    public seats : number = 0;
    public departuretime : number = 0 ;
    
    
}