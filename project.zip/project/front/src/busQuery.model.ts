export default class Busquery{
source:string='';
destination:string="";
dateOfDeparture:string='';
}