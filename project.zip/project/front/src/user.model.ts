export class User {
    public id:number=0;
    public name: string = '';
    public email: string = '';
    public password: string = '';
    public phoneNumber:string = "";
}