export class Role{
    public roleId : number = 0;
    public userId : number = 0;
}