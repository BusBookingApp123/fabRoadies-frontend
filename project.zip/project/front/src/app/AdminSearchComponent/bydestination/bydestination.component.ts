import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bydestination',
  templateUrl: './bydestination.component.html',
  styleUrls: ['./bydestination.component.css']
})
export class BydestinationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
