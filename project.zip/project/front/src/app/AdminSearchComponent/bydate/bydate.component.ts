import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bydate',
  templateUrl: './bydate.component.html',
  styleUrls: ['./bydate.component.css']
})
export class BydateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
