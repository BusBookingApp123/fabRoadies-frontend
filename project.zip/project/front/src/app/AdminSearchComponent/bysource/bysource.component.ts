import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bysource',
  templateUrl: './bysource.component.html',
  styleUrls: ['./bysource.component.css']
})
export class BysourceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
