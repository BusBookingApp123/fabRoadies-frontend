import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-buses-found',
  templateUrl: './no-buses-found.component.html',
  styleUrls: ['./no-buses-found.component.css']
})
export class NoBusesFoundComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
  }

}
