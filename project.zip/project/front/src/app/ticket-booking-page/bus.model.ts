export class bus{
    public busno! : string;
    public agency! : string;
    public busType! : string;
    public departureCity! : string;
    public arrivalCity! : string;
    public dateOfDeparture! : string;
    public price! : number;
    public seats! : number;
    public departuretime! : string
}