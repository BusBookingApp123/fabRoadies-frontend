import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bus-list',
  templateUrl: './bus-list.component.html',
  styleUrls: ['./bus-list.component.css']
})
export class BusListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
