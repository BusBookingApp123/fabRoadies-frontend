import { BusAdmin } from "./BusAdmin.model";
import { User } from "./user.model";

export class Ticket {
ticketId:number =0;
busno:string='';
price:number =0;
reservationDate:string ='';
//user:User=new User;
//passenger:Passenger=new Passenger;
source:string='';
destination:string='';
bustype:string='';
booked:string="true";

}
