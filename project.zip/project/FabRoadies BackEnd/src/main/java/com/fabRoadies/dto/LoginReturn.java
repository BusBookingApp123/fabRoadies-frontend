package com.fabRoadies.dto;






//@Entity
public class LoginReturn {
	
//	@Id

	private int roleId;
	
	private int userId;

	public int getRoleId() {
		return roleId;
	}

	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	
}
